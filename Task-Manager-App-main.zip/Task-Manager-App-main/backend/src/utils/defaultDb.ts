import { defaultDatabase } from './restoreDB';

defaultDatabase();
