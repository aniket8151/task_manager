import { createContext } from 'react';

const ContextApp = createContext();

export default ContextApp;
